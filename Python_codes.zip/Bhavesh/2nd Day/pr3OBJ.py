## OBJECT ORIENTED PROGRAMMING 

#class first_class:
#    def print_hello(self):
#        print ("hello")
#        print("this is Object Oriented Programming")
#
#obj=first_class()
#obj.print_hello()
#
#
#class s_class:
#    def hello(self):
#        print("hellow sir")
#    def call(self):
#        self.hello()
#o=s_class()
#o.call()
#
#
#class name(object):
#    def __init__(self):
#        self.name='bhavesh'
#    def p_name(self):
#        print ("my name is: ",self.name)
#rk=name()
#rk.p_name()


# inharitance 

class perent_class(object):
    def __init__(self):
        print ("constructor called")
        self.a=10
        self.b=20
    def mymethod(self):
        print ('self',self.a)
        print ('self',self.b)
    def print_method(self):
        print('print method')

class child_class(perent_class):
    def child_method(self):
        print("print child")
    def call_parent_method(self):
        self.mymethod()
ch_obj=child_class()
ch_obj.child_method()
ch_obj.print_method()
print (ch_obj.a)
print (ch_obj.b)


class car():
    def color(self):
        print ("red")
        print ('black')
        print ("white")
    def model(self):
        print ("swift")
        print ("honda city")
        print ("scorpio")
        print ('oddi')
class company(car):
    def names(self):
        print ("Hoda")
        print ("BMW")
        print ("tata")

c=company()
c.model()
c.color()
c.names()