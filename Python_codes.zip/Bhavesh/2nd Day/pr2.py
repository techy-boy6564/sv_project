# looping in list

#num=int(input("enter the number: "))
#for i in range(num):
#    print(i)

## LOOPINT IN LIST

#x=[1,2,3,4,5,6,7,8,9]
#for ele in x:
#    print (ele)

## looping in tuple

#y=(1,2,3,4,5,6,7,8,9)
#for item in y:
#    print(y)

## looping in string

#my_str='serpentCS'
#for char in my_str:
#    print (char)


## looping in dictionary

dict1={'a':1,'b':12,'c':123,'d':453}
#for key in dict1.keys():
#    print ('keys',key)
#for val in dict1.values():
#    print ("values",val)

for key,value in dict1.items():
    print(key,value)