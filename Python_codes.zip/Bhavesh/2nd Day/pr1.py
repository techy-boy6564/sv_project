# Dictionary Practice
St_dict={
    'about':'Py.Dev',
    'name':'bhavesh',
    'clg':'SV',
    'city':'S.nagar',
    'add':'SST'
}
# print Dict

print(St_dict)
print("First val by index is: ",St_dict['name'])


# Dict functions 

print ("\nlist of dict keys",St_dict.keys())
print ("\nprint values of dict",St_dict.values())
print ("\nitems of dit",St_dict.items())

# iter func. example 


it=iter(St_dict) # it is obj of iter
print(next(it))
print(next(it))
print(next(it))
print(next(it))
print(next(it))

# there is list and convert it 
x=[('a',1),('b',2),('c',3),('d',4)]
print("\nthis is a list ",x)

dict1=dict(x)
print ("\nconvert list into dict is  ",dict1)

# clear the dict
x={
    'a':123,
    'b':456,
    'c':789    
}
print("\ndictionary is: ",x)
x.clear()
print("\ncleared dict is ",x)

# two obj of same dict

dict20={
    'a':234,
    'b':23,
    'c':1231,
    'd':31
}
dict5=dict20
dict6=dict20

dict5['key1']='new val'
print ("\nusing dict5: ",dict5)
print ("\nusing dict6: ",dict6)



## SEPARATE COPY OF DICTIONARY"

dict23={
    'a':234,
    'b':23,
    'c':1231,
    'd':31
}
copy_dict23=dict23.copy()
copy_dict24=dict23.copy()
print("\norg dict is : ",dict23)
print('\ncopy 1 is : ',copy_dict23)
print("\ncopy 2 is : ",copy_dict24)

dict21={
    'a':234,
    'b':23,
    'c':1231,
    'd':31
}
print("\nF disct",dict21)
st_dict=dict21
del dict21['a']
print("\nS dict",st_dict)

# get specific  val of key and if not exist it will return none

dict10={
    'a':234,
    'b':23,
    'c':1231,
    'd':31
}
print (dict10)
val=dict10.get('d')
print (val)
val2=dict10.get('e')
print ("\nif key will not exists then get method will return none like bellow ")
print (val2)

# print value of key "d" if it exist

print ("\nif key D is exist in dict: ",dict10['d'])

# iter key

print (dict1)
keys = list(dict1.keys())
for key in keys:
    print(key)

# iter val

print ("\ndict name is dict20: ",dict20)
for value in dict20.values():
    print ("\nprint iter values: ",value)


# print dict before poped

print ("\ndict23 before pop",dict23)
val=dict23.pop('a',0)
print ("\ndict23 after pop: ",dict23)
print ("\n poped val is: ",val)


#tuple pair

tuple_pair=dict5.popitem()
print ("\nprint tuple pair\n",tuple_pair)
print ("\npoped dict: ",dict5)



# set default val of dict

dict4={
    'a':24,
    'b':12,
    'c':412,
    'd':123
}
print("\nDict4 : ",dict4)
res=dict4.setdefault('a',2)
print("\nres var is: ",res)
print ("\ndict is: ",dict4)

# how will we find string by index

strx="hello this is the STRING"
result=strx.find('STRING')
print (result)
result=strx.find('STR')
print ("substring find from right",result)

# find index number of perticular character 

line='tHis is the Test'
print (line)
ind=line.find('H')
print ("index number of H is ",ind)

#  check alphanumeric string 
str2="bhavesh123"
print(str2)
alnum=str2.isalnum() # it's a boolean function 
print("IS STRING ALPHANUMERIC?",alnum)



# is string alphabetic
print(str2)
al=str2.isalpha()
print("IS STRING ALPHABETIC?",al)

# get the number from string

num=str2.isdigit()
print("IS STRING NUMERIC OR HAVING ALL DIGITS?",num)

str3="THIS IS THE STRING"
# get upercase letter
upper=str3.isupper()
print ("IS THE STRING IN UPPERCASE?", upper)

low=str2.islower()
print(low)

# find space in string
space=str3.isspace()
print ("IS THE STRING HAVING ONLY SPACE?", space)

# split in string 

x='example of split and join '
split_list=x.split(' ')
print ("SPLIT LIST FROM STRING", split_list)
 
# find split till given index number
rsplit=str3.rsplit(' ',3)
print ("\nRIGHT SPLIT LIST FROM STRING",rsplit)

split_list=x.splitlines(2)
print("\nsplit line",split_list)

join_str=','.join(split_list)
print("join string from the list of string",join_str)

lower_str=','.join(split_list)
print("join string from the list of string",join_str)


# convert string to lower case 
lower_str=strx.lower()
print("STRING CONVERTED TO LOWER CASE: ", lower_str)

# convert uper case
uppr_str=strx.upper()
print("string converted to upper case: ",uppr_str)


#  string with case swap

swap_case=strx.swapcase()
print ("swapp the string: ",swap_case)

# titled string 

title_str=strx.title()
print ("titled string: ",title_str)

# set functions 

F_set={1,2,3,4,5}
print(F_set)
F_set.add(6)
print("add the val 6: ",F_set)
F_set.remove(1)
print ("remove the val 1: ",F_set)
res=F_set.pop()
print("arbitary set: ",res)
print("remove 1 element from the set")
F_set.clear()
print ("clear the set: ",F_set)

# create copy of the set

s_set={1,2,3,4,5,6,7}
set_x=s_set.copy()
set_x.add(8)
print ("F_set: ",s_set)
print ("Set_x: ",set_x)

#print difference between two sets

a_set={1,2,3,4,5}
b_set={6,7,8,9,0}
print("\nset a_set: ",a_set)
print("set b_set: ",b_set)
c_set=b_set.difference(a_set)
print("difference between two sets ",c_set)

# intersection between sets

c_set=a_set.intersection(b_set)
print("intersection of set: ",c_set)

# union of sets a and b as set c

c_set=a_set.union(b_set)
print("union of sets ",c_set)

c_set=a_set.symmetric_difference(b_set)
print("symmetric diierence",c_set)

# sub set

res=a_set.issubset(b_set)
print("true is set x is a subset of set z",res)

# supper set

res=b_set.issuperset(a_set)
print (res)

# TRUE IF BOTH SET X AND SET Z ARE DIFFERENT SET AND HAVE NULL INTERSECTION

c_set=set(range(11,18))
res=a_set.isdisjoint(c_set)
print (res)

a_set.update(c_set)
print("set x update with element of set",a_set)