# # IO in python 
#  
# print ("enter some values")
# x=input()
# print (x,type(x))
#  
# y=int(input("enter the number"))
# print(y,type(y))


name2=input("enter your name: ")
print ("hellow "+name2+"!" )


x=range(1,8)
print (x)