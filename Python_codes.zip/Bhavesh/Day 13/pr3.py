# Dictionary Practice 

import time

Friends={
    1:'Khushal',
    2:'Karan',
    3:'Harsh',
    4:'Jaydeep'
}
Friend={
    5:'Shidhhraj',
    6:'Kripal',
    7:'Ronak'
}

print ('\ndictionary 1:',Friends)
print ('dictionary 2:',Friend)

print('\nlength of dict1',len(Friends))
print('length of dict2',len(Friend))

print('\nkeys of dict 1 is: ',Friends.keys())
print('keys of dict 2 is: ',Friend.keys())

print('\nValues of dict1 is: ',Friends.values())
print('Values of dict2 is: ',Friend.values())

print('\nitems of Dict1 is: ',Friends.items())
print('items of Dict2 is: ',Friend.items())

print('\nget value of key1 of dict1 : ',Friends.get(1)) # takes key in parameter and return value of given key
print('get value of key5 of dict2 : ',Friend.get(5))

print('\nupdate dict1: ',Friends.setdefault(5,'bhavesh'))
print (Friends)
print('update dict2: ',Friend.setdefault(8,'Pankaj'))
print(Friend)

test4=Friends.copy()
print('\ncopy dict1 by dict2: ',test4)
test5=Friend.copy()
print('copy dict2 by dict1: ',test5)

e=[1,2,3,4,5,6,7,8,9]
new=dict.fromkeys(e,'val') # To create a dictionary
print('\nThis is new dict, created by Fromkeys',new)

print(Friends.pop(5))
print('\npopped dictionary 1: ',Friends)
print(Friend.pop(8))
print('Popped dictionary 2: ',Friend)

Friends.update(Friend)
print('\nDict1 update by Dict2',Friends)
Friend.update(Friends)
print('Dict2 update by Dict1',Friend)

try:
    print('\n',Friends)
    print(Friend)
    time.sleep(0.9)
except:
    print('dict is not exist')
finally:
    Friends.clear()
    print('\nDict1 is Cleared successfully',Friends)
    Friend.clear()
    print('Dict2 is cleared successfully',Friend)