# Set Practice

st={1,2,3,4,5}
print(st)
st.add(6)
print(st)

stw=st.copy()
print(stw)

# st.clear()
# print(st)