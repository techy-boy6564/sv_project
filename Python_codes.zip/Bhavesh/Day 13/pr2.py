# List Practice 
# if any list contain a single type of Datatype it is called Homogeneous
# if any list contain a multiple type of Datatype it is called Heterogeneous

import time

li1=[1,2,3,4,5,6,7,8,9,9,9] # Homogeneous
li2=[1,2,3,1.2,2.3,3.4,'Python','programming','Language'] # Heterogeneous

print('org list 1 is: ',li1)
print('org list 2 is: ',li2)

li1.append(10) # append method
print('append 10 in li1 ',li1)

li1.extend(li2)
print('extend list 1 and list 2',li1)

li1.insert(0,0)
print('insert 0 in list1 ',li1)

li1.remove(10)
print('remove 10 in list1 ',li1)

li1.pop()
print('pop last element of list 1 ',li1)

print('this is list 2 ',li2)
print('clearing list2 ')
time.sleep(00.9)
li2.clear()

try:
    print(li2)
except:
    print('list not exist')

finally:
    print("list2 clearing successfully")

print(li1)
ind=li1.index(3.4)
print ('index of 3.4 in list1 ',ind)

c=li1.count(9)
print('count of 9 in list1  ',c)

li1.reverse()
print('reverse of list1 is : ',li1)

li3=[1,2,3,4,5]
li3.sort()
print('sorting in new list3 is: ',li3) 

# li1=list(range(1,7))
# print('range between 1 to 7 fo list1 : ',li1)

# special methods of list

t1=li1.__len__()
print(t1)

t2=li1.__getitem__(3) # take index and return item 
print(t2)

li1.__setitem__(3,5) # Sets the element at the specified position i in the list to x.
print(li1)

li1.__delitem__(0) # takes index nad removes the item from left to right
print(li1)

tf=li1.__contains__(3.4) # Returns True if the list contains an element x, False otherwise.
print(tf)

li4=li1.__add__(li3)
print('S_adding list 1 and 3 in list4 ',li4)

li1.__iadd__(li3)
print('iadd method',li1)

f=li1.__mul__(3) #Returns a new list that is a repetition of the original list n times.
print('mul method ',f)

li5=[5,6,7,8,9,0]
li5.__imul__(2)
print('imul method',li5)

for i in reversed(li5):
    print(i)

