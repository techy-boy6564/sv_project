# Tuple Practice 

tup=('fruits','apple','cherry','banana','orange','kiwi','grapes','apple','apple')

print ('org tuple',tup)
print ('length of tuple',len(tup))
print ('count method on Apple',tup.count('apple'))
print ('index method on cherry',tup.index('cherry'))

# update tuple by convert into a list

li=list(tup) # convert tuple into list
li[2]='mango' # update the list
tup=tuple(li) # convert back into a tuple 
print('updated tuple: ',tup)