# all function of set 

my_set ={9,1,2,3,4,5,6,10,11,12,13} # with {} we can create set 
my_set2={12,13,14,15,16,17,18}
print (my_set)

# second way to crate set 
my_set1 = set() 
my_set1={1,2,3,4,5,6,7,8,9,10,11,12}
print (my_set1)
print (my_set)

print(len(my_set1)) # print length of set

my_set.add(12)
print (my_set)


my_set1.remove(8)
print (my_set1)

res=my_set.union(my_set1,my_set2)
print(res)


print(my_set.pop()) # remove last element of set

set=my_set.difference(my_set1) # Use the difference() method to get the elements in set1 but not in set2
print (set)

my_set3=my_set.intersection(my_set1) # Use the intersection() method to get the common elements
print ('this is from intersection: ',my_set3)

res=my_set1.symmetric_difference(my_set2) # Use the symmetric_difference() method to get the unique elements
print ('this is from symmetric_Difference ',res)


sup={1,2,3,4,5,6,7,8}
sub={1,2,3,4,5}
res=sup.issubset(sub) # Use the issubset() method to check if set2 is a subset of set1
print(res)

res2=sup.issuperset(sub) # Use the issuperset() method to check if set1 is a superset of set2
print(res2)

sub.update(sup)
print(sub)
