# all functions of string 

str1='this is the python programming language'
str2='   python is OOP language    '

# cap=str2.capitalize()

print(len(str1))
print(len(str2)) # return total length of given string in perameter

print(str1.upper()) # return full string in upper case 
print(str1.lower()) # return full string in lower case

print(str1.capitalize()) # return first letter in upper case of  string

print ('strip: ',str2.strip()) # remove the whitespace from the strig 

print (str1.split())

print ('replace: ',str1.replace(str2,str1))

print('from starts with: ',str1.startswith('this'))
print(str1.startswith('the'))

print('from ends with: ',str1.endswith('language'))
print(str1.endswith('python'))

print ('from count: ',str1.count('i'))

print('find : ',str1.find('p'))
print(str1.rfind('l'))

print('ind of py: ',str1.index('py'))

print(str1.isspace())

print (str1.swapcase())

print (str1.isalpha())
print (str1.isalnum())
print (str1.isdigit())
print (str1.isupper())
print (str1.islower())
