# all fuctions of list 

list=[1,2,3,4,5,6,9,7,8,9,0]
list1=[11,12,13,14,15]

print (len(list)) # len function
print ('count method: ',list.count(9))
list.append(10)
print (list) # append function

list.extend(list1) # extend function
print (list)

list.insert(2,16) # insert function
print (list)

list.remove(16) # remove fun--ction 
print (list)

list.pop(0) # pop function
print (list)

print (list.index(15)) # return index of given value in perameter

list.insert (11,12)
print (list)
print (list.count(12)) # it will return the number of duplicate value 

list.reverse() # reverse function
print(list)

list.sort() # sort function
print (list)



print (type(list)) # type function

list=range(1,9)  # it will return list acording to given perameters like 1,9
print (list)

