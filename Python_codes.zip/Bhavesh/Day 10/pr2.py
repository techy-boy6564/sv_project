# all functions of dict1ionary

dict1={
    1 : 'bhavesh',
    2 : 'karan',
    3 : 'Khushal',
    4 : 'harsh',
    5 : 'jaydeep'
      }
dict2={
    1:'sidhharth'
      }

print('org dict1 is: ',dict1)
print (len(dict1))
print ('from key function: ',dict1.keys())
print ('from value function: ',dict1.values())
print ('from items function: ',dict1.items()) # LIST OF TUPLE HAVING KEY-VAL PAIR
print ('from get method: ',dict1.get(2)) # return value of given key
print ('from pop method: ',dict1.pop(1)) # it will remove velue of given key
print (dict1)

dict1.update(dict2)
print ('from update: ',dict1) 
dict2.clear()
print ('dict1ionary has been creared',dict1)
print (dict1)
val=dict1.copy()
print ('from val: ',val)