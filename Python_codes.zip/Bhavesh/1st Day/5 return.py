# argument and return 

def sum(a,b):
    c=a+b
    return c
print ("method with return")
sum(10,15)