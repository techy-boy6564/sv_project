x=0
while x <10:
    print ("x",x)
    x=x+1
else:
    print("x is ",x)