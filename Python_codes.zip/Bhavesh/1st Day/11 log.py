x=int(input("enter the nubmer: "))
y=int(input("enter the nubmer: "))
if x == 10 and y ==15:
    print ("Both condition are True")
if x >= 10 or y != 15:
    print ("atlease one is True")
if not x > 10:
    print ("the opp cond is false")
    