het_x=[1,2.5,'s',5,'f',4.5,'run']
print ("HEXT",het_x,type(het_x))
