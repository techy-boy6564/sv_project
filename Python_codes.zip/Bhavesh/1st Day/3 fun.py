def hello():
    x=13
    y=14
    add=x+y
    print("addition is ",add)
    print ("hellow world")
print ("the method calling")
hello()