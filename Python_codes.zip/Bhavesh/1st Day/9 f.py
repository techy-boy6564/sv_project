def power (num,pow=1):
    return num ** pow
print ("calling with power functions " )
pow1=power(2,3)
print(pow1)
print ("calling without pow")
pow=power(5)
print (pow)