# Programm for Bitwise operators

a=int(input('enter the number: '))
b=int(input("enter the second number: "))
left_shift=b<<a
print("left_shift",left_shift)
right_shift=b>>a
print("right_shift",right_shift)
bit_and=a&b
print ("Bit and",bit_and)
bit_or=a | b
print ("Bit OR",bit_or)
bit_xor=a^b
print("bit_xor",bit_xor)
bit_not= ~a
print("Bit not",bit_not)