x=10
if (x > 5):
    print("x is greater than 5")
if (x < 11):
    print("x is less then 11")
if (x >=10):
    print ("x is greater than equal to 10")
if (x <= 10):
    print ("x is less than equal 10")
if (x == 10):
    print ("x is 10")
if (x != 5):
    print ("x is not 5")

if (x is 10):
    print ("yes, x is 10")

if (x is not 11):
    print ("no x is not 11")