tuple1=(1,3,5,2,6,8,4,2)
tuple2=(2,4,1,6,8,3,'help')
print (tuple1)
print (tuple2)

new_tuple=tuple1.__add__(tuple2)
print("new tuple",new_tuple)
new_tuple=tuple1+tuple2
print ("new tuple",new_tuple)
print (tuple1)


print ("count of element 3 in new tuple",new_tuple.count(3))
print ("index of element 5 in new tuple ",new_tuple.index("help"))
x=[1,2,3,4,5,6,7,8]
x_tuple=tuple(x)
print("list converted to tuple",x_tuple)
x_list=list(x_tuple)
print ("tuple converted to list",x_list)
