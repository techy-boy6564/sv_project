def power(num,pow=1):
     return num ** pow
print ("calling with power function")
pow1=power(2,3)
print (pow1)
print ("calling without power functons")
pow2=power(5)
print(pow2)