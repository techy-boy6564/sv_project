stex='python'
print (stex,type(stex))
stx=123
print(stx,type(stx))
strx_null=''
# if we define empty variable
# with duble or single 
# inverted comma so 
# interpreter treat as a string
print(strx_null,type(strx_null))