x=0.0
if isinstance(x,int):
    print("x is integer")
elif isinstance(x,float):
    print("x is float")
elif isinstance(x,bool):
    print("x is boolean")
elif isinstance(x,str):
    print("x is string")
else:
    print("x is a complex data type")
