int_x=[1,2,3,4,5,6]
print("int_x",int_x)
int_x.append(7)
print ("append element",int_x)

int_x.pop()
print ("pop element",int_x)

int_x.pop(2)
print ("pop second element",int_x)

int_x.remove(5)
print("remove 5 from list",int_x)

int_y=[11,12,13]
int_z=int_x.__add__(int_y)
print ("Add List",int_z)

int_w = int_x + int_y
print("Add list 1",int_w)

int_x.extend(int_y)
print("Add List 2",int_x)

x_list = range(1,8)
print ("list using range",x_list)

print ("index of element 5 is",x_list.index(5))
print ("attrs & methods of list",x_list.index(5))

Rrange=range(5)
Llist=list(Rrange)
Llist.insert(2,5)
print("insert in list ",Llist)

print ("count of element 5 in list is ",x_list.count(5))

x_list.reverse()
print("x list is reversed",x_list)
