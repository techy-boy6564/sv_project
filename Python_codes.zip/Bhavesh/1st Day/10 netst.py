def mul(a,b,c):
    print("main function called")
    def mul(x,y):
        print ("nested function called")
        return x*y
    e=a+b
    return mul(e,c)
result=mul(2,5,6)
print ("result 0f nested ",result)