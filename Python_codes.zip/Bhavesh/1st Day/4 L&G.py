num=(int(input("enter the first number: ")))
t=(int(input("enter the second number: ")))
if (num > t):
    print ("you have enter the number greter then in first position",t)
else:
    print("You have enter the number less then in second position",num)