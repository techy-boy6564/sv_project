Fs_dict={
    'one':'wahed',
    'two':'item',
    'three':'talata'
}
print ("value of key one is ",Fs_dict['one'])

Fs_dict['four']='Bhavesh'
print ("added key val pair for four in dictionary",Fs_dict)
