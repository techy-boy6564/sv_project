# Diffrence between Dictionaries

Dict1={
    "str1" : "string",
    'float': 1.3,
    'integ' : 123,
    'bool' : "true"
}
Dict2={
    'str2' : "python",
    'flost': 1.2,
    'integ':1234,
    'bool':"true"
}
if(Dict1 == Dict2):
    print ("Both Dictionaries are same\n",Dict1,'\n',Dict2)
else:
    print('both dictionaries are diffrent\n',Dict1,"\n",Dict2)
