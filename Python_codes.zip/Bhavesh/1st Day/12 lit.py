x=10*25+33-23/8
print ("literal expression: ",x)

a=10
b=15
c=13
d=14
e=8

res1=a*b+c-d/e
print ("result 1",res1)

res2=(a+b)*c-d/e
print("result 2",res2)