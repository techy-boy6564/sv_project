# all data types 

strx='python'
print(strx,type(strx))
inty=123
print(inty,type(inty))
floatx=23.2
print(floatx,type(floatx))
bool=True
print (bool,type(bool))
li=[12,34,'python','interpreter']
print(li,type(li))
tu=(456,234,'vscode','pycharm')
print(tu,type(tu))