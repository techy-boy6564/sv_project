# XPLICIT LINE JOINING using '\' Operator

#print ("explicit line joining example: ")
#x=[1,2,3,4,5,6,7,8,9]
#print ("all items",x)
#print ("Numbers divisible by 2 and 3")
#for item in x :
#    if item % 2 ==0 and item % 3==0:
#        print ("item",item)

print ("explicit line ")
y=[3,5,12,6,3,6,1,6,8,4,2,4,1]
print ("the items is ",y)
print ("number divisible by 2 and 3")
for item in y :
    if item % 3 == 0 and item % 4 == 0 :
        print ("items",item)
    else:
        print ("there is not any divisible number by 2 and 3")
