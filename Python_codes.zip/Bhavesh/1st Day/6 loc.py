x=10
def xy():
    x=20
    print ("local x var is: ",x)
xy()
print ("x",x)