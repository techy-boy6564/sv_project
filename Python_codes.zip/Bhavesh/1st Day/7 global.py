x=10
def xy():
    global x
    x=20
    print ("global x ",x)
    
xy()
print ("Local x",x)
