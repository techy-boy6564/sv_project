# undefined variable
x=1.20
print ("xxx",x,'type',type(x))
y=(12,1.2,"string")
print ("yyy",y,'type',type(y))
o=[1,32,34,63,4,23,23]
print("val of O is ",o,'and type of var is ',type(o))
p="Python"
print("p is ",p,'type is ',type(p))