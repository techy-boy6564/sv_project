int_x= [1,2,3,4,5,6]
print ("intx: ",int_x,type(int_x))
float_x = [1.2,2.3,3.4,4.5]
print ("float",float_x,type(float_x))
str_x=['a','b','c','d']
print ("String",str_x,type(str_x))
str2_x=['help','run']
print ("intx",str2_x,type(str2_x))
