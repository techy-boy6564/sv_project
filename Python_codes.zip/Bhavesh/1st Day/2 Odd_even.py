# odd or even 
print ("this is the programm for odd and even number")
num=(int(input("enter the number: ")))
if (num%2==0):
    print("you have enterd even number is: ",num)
else:
    print("you have enterd odd number is: ",num)