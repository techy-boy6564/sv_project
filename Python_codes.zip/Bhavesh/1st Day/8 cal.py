x=int(input("enter the fist number: "))
y=int(input("enter the second number: "))
print("you have enterd first number is ",x,'and')
print("You have enterd second number is ",y)
add=x+y
print ("Addition of entered number is: ",add)
sub=x-y
print ("Subtraction of entered number is ",sub)
mul=x*y
print ("Multiplication of enterdd number is: ",mul)
div=x/y
print ('division of entered number is: ',div)
mod=x%y
print ("Module of entered number is: ",mod)
pow=x**y
print ("POW of enterd number is: ",pow)
floor_div=x//y
print ("Floor of entered number is: ",floor_div)