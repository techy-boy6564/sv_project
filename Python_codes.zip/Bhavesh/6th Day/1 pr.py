# try and except practice 

x=[1,2,3,4,5,]
try: 
    print (x[5])
except:
    print ("invalid index")
else:
    print ("successfully")
finally:
    print('this will be always ')