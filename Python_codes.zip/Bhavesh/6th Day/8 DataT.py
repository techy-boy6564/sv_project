from datetime import datetime as TD

current_datetime = TD.now()
print ('current date and time: ',current_datetime)

current_date = TD.today()
print ('current date and time: ',current_date)

current_date = current_datetime.date()
print('current date : ',current_date)

current_day = current_datetime.time()
print('current time is: ',current_day)

current_day = current_datetime.day
print( 'day in the date ',current_day)

current_month= current_datetime.month
print ('current month is ',current_month)

current_year = current_datetime.year
print ('year in the date is ',current_year)

current_hour = current_datetime.hour
print ('current hour is ',current_hour)

current_minut = current_datetime.minute
print ('current minut is ',current_minut)

current_second = current_datetime.second
print  ('current second is ',current_second)

current_micro_second = current_datetime.microsecond
print ('current micro second is ',current_micro_second)

current_week = current_datetime.weekday()
print ("current weekday is ",current_week)

cur_time= current_datetime.ctime()
print('current time, ',cur_time)

iso_cal = current_datetime.isocalendar()
print ('iso',iso_cal)