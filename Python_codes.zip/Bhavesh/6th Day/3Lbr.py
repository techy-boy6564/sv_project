# use the standerd libraries 

import os
import sys
import datetime

print (dir(os))
os.system('ls')
print ("version info",sys.version_info)