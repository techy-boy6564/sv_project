# user defined Exception

class my_e(Exception):
    def __init__(self,value):
        self.value=value
    def __str__(self):
        return "my exception"+str(self.value)
my_list=[15.0,25.5,37.3,45.2]
try:
    print (my_list[5])
except:
    raise my_e('you must enter five element')
finally:
    print("the cleanup has been done")
if len(my_list)<4:
    raise my_e('the list should have ')