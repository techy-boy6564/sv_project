# user of OS library

import os
import time

# Print the current working directory
print("Current working directory:", {os.getcwd()})

# Create a new directory called "test"
os.mkdir("test")

# Check if a file named "example.txt" exists in the current directory
if os.path.isfile("example.txt"):
    print("example.txt exists!")
else:
    print("example.txt does not exist.")

# Rename the "test" directory to "new_test"
os.rename("test", "new_test")

# Remove the "new_test" directory
time.sleep(00.9)
# new_test dir will be removed after 1 sec
os.rmdir("new_test")