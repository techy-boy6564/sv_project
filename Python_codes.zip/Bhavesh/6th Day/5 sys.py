# use of system library

import sys

print ('command-line arguments : ',sys.argv)
print ('python version: ',sys.version)
print ('maximum ineger value: ',sys.maxsize)
sys.exit(1)