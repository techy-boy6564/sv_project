# date time 
import datetime

var=datetime.datetime.now()
print('this is current date time',var)
print ('current date',var.date())
print('current time',var.time())
print('current month',var.month)
print('current day',var.day)
print('current year',var.year)
print('current microsecond',var.microsecond)
print('current week day: ',var.weekday ())
print(var.isocalendar())# it returns 
print(var.isoformat())
print(var.isoweekday())
print(var.max)
print(var.min)
