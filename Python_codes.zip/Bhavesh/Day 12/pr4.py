from functools import reduce
# x,y=map(input().split())
add=lambda x,y:x+y
print (add(5,7))

sub=lambda w,r:w-r
print(sub(2,5))

mul=lambda m,l:m*l
print(mul(2,6))

div=lambda d,v:d/v
print(div(6,2))

# inline functions 
x=[y**3 for y in range(1,6)]
print(x)

y=123.12312312
print(round(y,2))

# lit=[1,2,3,2.3,3.4,5.6,'test','python','language']
lt=[1,2,3,4,5,6,7,8,9,10]
string=['this','is','test','of','python','lan','test']
# t=list(filter(lambda x:isinstance(x,int),lit))
# print(t)

w=list(map(lambda x : x*x,lt))
print(w)

p=list(map(lambda y:y+y,lt))
print(p)

a=reduce(lambda g,h:g+h,lt) # it will return addition of full list 
print(a)

assert a>50,'invalid '

f1 = open('pr3.py','r')

# Read the whole file in a string
x1 = f1.read()

# Execute the string which has python code
exec (x1)