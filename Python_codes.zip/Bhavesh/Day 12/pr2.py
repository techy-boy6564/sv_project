#  regular Expressions 

import re 

str='This is the test of programming.'
mail='bs0672001@gmail.com'

res2=re.search('is',str)
print('this is search method\n',res2)

q=re.compile(r'[a-z0-9.@]+[com]$')
res=q.match(mail)
r=re.compile(r'[a-z0-9.@]{15,25}')
mat=r.match(mail)
print ('this is proper mail id\n',mat)
print ('it has 15 to 20 length\n',res)


set={1,2,3,4,5,}
set2={3,4,5,6,7,8}
var=set.intersection(set2)
print (var)
set2.intersection_update(set)
print (set)
print (set2)
