import logging 
logging.basicConfig(
    format='%(asctime)s : %(message)s : %(levelname)s',
    filename='logging.log' ,
    level=logging.INFO
)

logging.info('start program')
logging.info('doing something')
logging.warning('dying now')
logging.error('shutdown the system')
logging.fatal('fatal error')
logging.critical('very critical')