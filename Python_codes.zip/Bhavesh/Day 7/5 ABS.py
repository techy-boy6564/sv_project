num1 = 5
num2 = 13.6
diff = abs(num1 - num2)
print (diff)


num= -7
abs_num=abs(num)
print(abs_num)

import cmath
c_num=1+3j
abs_c_num=abs(c_num)
print (abs_c_num)

num4 = -5 
if abs(num4) > 10:
    print ("the absolute value of num is greater than 10.")
else:
    print ("the absolute value of num is less  than or equal to 10")