import datetime

st_dt= datetime.date(2023,2,16)
ed_dt= datetime.date(2023,7,17)

interval = ed_dt - st_dt
interval = interval.days
new_start_date = st_dt
while new_start_date <= ed_dt:
    print ("::AAA:",new_start_date.weekday())
    print ("::NEW::",new_start_date)
    if new_start_date.weekday()==6:
        print ("::sunday::",new_start_date)
        interval -=1
    new_start_date += datetime.timedelta(days=1)
print("::INTERVAL",interval)
