# filter function 

age= [5,12,17,18,24,32,34]
def my_fun(x):
    if x<18:
        return False
    else:
        return True
adults = list(filter(my_fun,age))
for x in adults:
    print (x)
    
# EX2

