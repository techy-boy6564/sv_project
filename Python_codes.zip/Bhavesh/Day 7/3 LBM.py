# write a program using lambda
# lambda will take a argument and return a value
# it will take single line argument
# it is a anonymouse functionn

x=lambda x:x+10
print (x(5))

# EX 2

list=[(2,5),(1,4),(4,1,),(3,6)]
list.sort(key=lambda x: x[1])
print (list)

# EX 3

multi = lambda x,factor:x*factor
print (multi(5,6))

# EX 4 

max_num = lambda a,b :a if a>b else b
print (max_num(10,5))