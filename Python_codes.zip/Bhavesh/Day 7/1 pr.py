from datetime import datetime
from datetime import datetime as TD

current_datetime = TD.now()
print ('current date and time: ',current_datetime)

current_date = TD.today()
print ('current date and time: ',current_date)

current_date = current_datetime.date()
print('current date : ',current_date)

current_day = current_datetime.time()
print('current time is: ',current_day)

current_day = current_datetime.day
print( 'day in the date ',current_day)

current_month= current_datetime.month
print ('current month is ',current_month)

current_year = current_datetime.year
print ('year in the date is ',current_year)

current_hour = current_datetime.hour
print ('current hour is ',current_hour)

current_minut = current_datetime.minute
print ('current minut is ',current_minut)

current_second = current_datetime.second
print  ('current second is ',current_second)

current_micro_second = current_datetime.microsecond
print ('current micro second is ',current_micro_second)

current_week = current_datetime.weekday()
print ("current weekday is ",current_week)

cur_time= current_datetime.ctime()
print('current time, ',cur_time)


iso_cal = current_datetime.isocalendar()
print ('calander: ',iso_cal)

iso_format = current_datetime.isoformat()
print ('iso format is: ',iso_format)

iso_weekday = current_datetime.isoweekday()
print ('iso week day : ',iso_weekday)

dt_max = datetime.max
print('dt_max:', dt_max)

dt_min = datetime.min
print ('dt_min ',dt_min)

new_dtime=current_date.replace(day=25)
print ("replaced new data and time",new_dtime)

current_timestruct = current_datetime.timetuple()
print ('current time structure: ',current_timestruct)

dt_str = current_datetime.strftime('%d-%m-%y %H:%M:%S')
print ('dt_str',dt_str)

new_dt = current_datetime.strptime(dt_str,'%d-%m-%y %H:%M:%S')
print ('new date and tiem is ',new_dt)