# inline function


x=[1,2,3,4,5]
y=[]
for ele in x:
    y.append(ele*ele)
print (y)

p=[ele*ele for ele in range(1,6)] 
print(p)


# inline function with loop 

x = [1,2,3,4,5,6,7,8,9,10]
y = []
for ele in x:
    if ele%2==0:
        y.append(x)
print ('without inline function',y)

# with inline funciton 

y= [ele for ele in range(1, 11)if ele % 2 == 0]
print ('with inline function: ',y)

z= abs(-10.34)
print ("absolute val is: ",z)

z=round(10.9876433210)
print (z)