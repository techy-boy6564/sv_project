list=[1,2,3,4,5,6]
try:
    print(list[8])
except:
    raise Exception("invalid index")
else:
    print ("successful")
finally:
    print ("programm complated")