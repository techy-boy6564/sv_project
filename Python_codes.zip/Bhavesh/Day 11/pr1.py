# file operations 
import os
import time
str='this is python file handling for existing file'
f = open("hello.pdf", "w")
print(f.write(str))
f.close()

f=open('hello.pdf','r')
print(f.read())
f.close()

f=open('demo.txt','r')
print(f.readlines())
f.close()

f=open('demo.txt')
for i in f:
    print(i)
f.close()


time.sleep(00.9)

if os.path.exists('hello.pdf'):
    os.remove("hello.pdf")
else:
    print ('the file does not exist')