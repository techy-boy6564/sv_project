# constructor 

class f(object):
    def __init__(self):
        self.f='bhavesh'
    def print_f(self):
        print ("my name is :",self.f)
    def __del__(self):
        print('programm successful destroid')

obj=f()
obj.print_f()
print('this is the python program')