# overridding method 

class parent(object):
    def __init__(self, a, b):
        self.a = a
        self.b = b
    
    def add_member(self):
        return self.a + self.b

class child(parent):
    def __init__(self,x,y,z):
        super(child,self).__init__(x,y)
        self.c=z
    def add_member(self):
        res=super(child,self).add_member()
        return self.c+res
obj=child(4,6,9)
obj.add_member()