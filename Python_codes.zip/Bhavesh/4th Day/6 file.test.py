import os
import time

test2='test2.txt'

if os.path.exists(test2):
    print("File already exists")
else:
    print("File does not exist")
    
f=open('test2.txt','w')
f.write('this is the test of file handling')

if os.path.exists(test2):
    print("File created successfully")
else:
    print("file creation faild ")

f.close()
if f.close:
    print ('file is closed successfully')
else:
    print('file is still open')

os.remove('test2.txt')
time.sleep(0.1)

if os.path.exists(test2):
    print('Operation failed')
else:
    print('File removed successfully')