# write a program using all functions of the file managemnet in python

import os

with open ('test.txt','w') as f:
    f.write('this is the test of the python ')
    
with open ('test.txt','r') as f:
    contents = f.read()
    
os.remove('test.txt')

with open ("new_test.txt",'a') as f:
  f.write('\n this is some editing in the file, this is the test  of the python ')


with open ('new_test.txt','r') as f:
    contents = f.read()
    print(contents)

#r2=open ('new_test.txt','r')
#new_file=r2.readline()
#print(new_file)

r3=open('new_test.txt','r')
new_file=r3.readline()
print(new_file)
new_file=r3.readline()
print(new_file)
new_file=r3.next()

r3.close()

# print the file and stor it in a list where every line is a element of the list

f1=open('new_test.txt','r')
str=f1.readlines()
print (str,type(str))

f2=open('new_test.txt','a')
str2='this is the appended line in the file'
f2.write(str2)

f2.close()

f3=open('new_test.txt','r')
print("this is the test",f3.seek(4))
