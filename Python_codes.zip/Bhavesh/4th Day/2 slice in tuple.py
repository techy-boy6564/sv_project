tuple = (1,2,3,4,5,6,7,8,9)
print (tuple)

print 'first three element is: ',tuple[:3]
print 'three element  starting form index 3 to 6',tuple[3:6]
print 'last three element',tuple[-3:]
print 'all element except the last element',tuple[:-1]
