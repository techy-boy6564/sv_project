# constructor and Destructor 
# contructor ex1

class person:
    def __init__(self,name,age):
        self.name=name
        self.age=age
    def get_det(self):
        print("name is: ",self.name)
        print('age is:',self.age)
p=person('bhavesh',22)
p.get_det()
p=person('pankaj',22)
p.get_det()

# constructor ex2

class test:
    def __init__(self,paper,time):
        self.paper=paper
        self.time=time
    def exam(self):
        print("paper is:",self.paper)
        print('time is',self.time)
t=test('Python',9)
t.exam()
t=test("java",11)
t.exam()

# Destructor

class car:
    def __init__(self,name):
        self.name=name
        print(' is born',self.name)
    def __del__(self):
        print('is no more',self.name)
test=car('BMW')
test=car("Honda Ciry")
del car