list=[1,2,3,4,5,6,7,8]
print (list)
print (list[:3]) # before ' : ' is start val and after " : " is end value

print (list)
print ("start form IND 3 to IND 6",list[3:6]) 

print ("list tree ELM is: ",list[-3:])

print 'all ELM except the last ELM: ',list[:-1]
