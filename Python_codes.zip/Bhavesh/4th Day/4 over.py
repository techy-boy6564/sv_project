# Overriding methods using super

class perent(object):
    def __init__(self,a,b):
        self.a=a
        self.b=b
    def add_member(self):
        return self.a + self.b
class child(perent):
    def __init__(self,x,y,z):
        super(child,self).__init__(x,y)
        self.c=z
    def add_members(self):
        res=super(child,self).add_member()
        return self.c + res 
m=child(2,3,5)
m.add_members()