import pickle

class dump_class(object):
    def __init__(self):
        self.a=10
    def print_my_data(self):
        print("dumpped class data",self.a)
obj=dump_class()
f3=open('file.dat','w')
pickle.dump(obj,f3)
f3.close()
del obj
f4=open('file.dat','r')
new_obj=pickle.load(f4)
new_obj.print_my_data()
print (new_obj.a)