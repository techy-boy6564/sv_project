x=[1,2,3]
y='ok' 
try:
    print (x[3])
    
except:
    
    print ("element is not available",y)