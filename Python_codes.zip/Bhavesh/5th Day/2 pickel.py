import pickle

def write():
    f=open('test.dat','wb')
    lst=['pankaj','kripal','bhavesh','ronak']
    pickle.dump(lst,f)
    f.close()
def readit():
    f=open('test.dat','rb')
    list=pickle.load(f)
    print(list)
    f.close()


print("List data successfully stored")


def write2():
    f=open('D_read.dat','wb')
    D={'name':'bhavesh','clg':'sv','city':'surendranagar'}
    pickle.dump(D,f)
    f.close()
def readit2():
    f=open('D_read.dat','rb')
    Di=pickle.load(f)
    print(Di)
    test=pickle.load(f)
    f.close()
    
write()  
readit()

write2()  
readit2()

print("Dictionary data successfully stored")
