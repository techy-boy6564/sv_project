x=[1,2,3]
try:
    print (x[3])
except Exception,e:
    print ('error',e)