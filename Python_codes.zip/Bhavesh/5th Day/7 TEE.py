x=[1,2,3,4,5,6,7,8,9]
try:
    print (x[2])
except:
    print("invalid index")
else:
    print("successful")

try:
    f=open('test.txt','w')
    
except FileNotFoundError:
    print('the file was not found')
    