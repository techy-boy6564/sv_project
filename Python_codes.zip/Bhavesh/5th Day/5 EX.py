try:
    x=5/2
except:
    raise ArithmeticError


try:
    var = 8
    print ('var',var)
    print (var/4 )

except ZeroDivisionError:
    print ('divided by zero')
except:
    print ("error occurred")
    
    
x=[1,2,3]
try:
    print (x[3])
except Exception, e:
    print ("Error: ",e)