import os

# create file and write content

f=open('revision.txt','w')
f.write('this is the revision of file handlig programs ')
f.close()

# open same file and read the content

f=open('revision.txt','r')
test=f.read()
print (test)
f.close()

# open same file and append it

f=open('revision.txt','a')
f.write('this is teh second line')

#rename the furrent text file 

current_name='revision.txt'
new_name='test_file.txt'

os.rename(current_name,new_name)

print ('the file has been renamed')

test=f.tell()
print(test)