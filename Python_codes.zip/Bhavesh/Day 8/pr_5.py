import os
import sys
import platform

os.mkdir('test')
os.system('ls')
os.system('pwd')
print (platform.platform())
os.rmdir('test')
print ('vr',sys.version_info)
print ('version',sys.version)