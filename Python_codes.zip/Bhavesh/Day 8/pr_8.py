Add=lambda x: x+5
print(Add(10))

sub=lambda y:y+2
print (sub(10))

mul=lambda p:p*2
print (sub(10))

div=lambda q:q/2
print (div(10))

