# Created EXtra codes of python

# example 1

list1=['bhavesh','pankaj','kripal','khushal','harsh','karan']
for i in list1:
    print (i)
    

# example 2
#x=int(input('enter the number'))
#for i in range(x+1):
#    for j in range(0,i+1):
#        print ("x",end="")
#    print (" ")
    
#example 3

str='bhavesh,pankaj,kripal'
print (str,type(str))

inter=(1,2,3,4,5,6,7)
print(inter,type(inter))

list=['karan','khushal','harsh','pankaj']
print (list,type(list))

tuple=(1,2,3,4,5,6,7)
print (tuple,type(tuple))

integer=12
print(integer,type(integer))


