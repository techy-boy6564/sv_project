def cal(a,b):
    c=a+b
    print (c)
    c=a-b
    print (c)
    c=a*b
    print (c)
    c=a/b
    print (c)

x=int(input('enter the val 1: '))
y=int(input('enter the val: '))
cal(x,y)


