# Regular Expression

import re

# re.compile used to validate the string 

name='bhaveshsolanki'
test=re.compile('bha')
ok=test.match(name)
print (ok)
print (name[0:3])

# without obj of string

obj=re.compile('luc')
obj2=obj.match('lucifermorningstar')
print('from re.compile: ',obj2)

# re.search used for search value 

str='bhaveshsolanki'
objs=re.search('bha',str)
print('from re.search: ',objs)

# re.sub used to replace existed val
str2='bhavesh'
obj=re.sub('bhavesh','bhavu',str2)
print(obj)

# re.findall used to get a list of repited val

obj5=re.findall('a','bhaveshsolanki')
print(obj5)

# re.split it will convert a string into many parts, it takes three ARGs 
str2='mynameismaheshkumarmakwana'
objss=re.split('m',str2)
print (objss)

# return an iterator obj and we havet to extract obj form it
tr2='mynameismaheshkumarmakwanawwwwwwww'
bj=re.finditer('w',tr2)
print (bj)
for ob in bj:
    print (ob)