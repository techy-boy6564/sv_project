# cont.

x=1.2
y=2
if isinstance(y,int):
    print ('x integer')
if isinstance(x,float):
    print ('y float')
    

# functions

def cal_avg(number):
    total = sum(number)
    average = total/len (number)
    return average
score = [34,56,78,98,65,45,34,25]
average_score = cal_avg(score)
print ('the average score is: ',average_score)
