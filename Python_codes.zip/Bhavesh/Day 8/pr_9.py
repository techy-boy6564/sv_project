a=[list*list for list in range(1,9)]
print (a)

b=[ele for ele in range(1,11) if ele%2==0]
print (b)