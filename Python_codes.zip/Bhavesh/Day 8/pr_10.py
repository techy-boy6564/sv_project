# absolute, round and filter function 

a=abs(-0019.9000) # it eill ignore the Zero and return absolute value
print (a)


b=round(23.22234234234,3) # First a float value and second decimal precision by which you
#want to round,Here 2 means it will round up to 2 decimal precision
print (b)


# filter
list=[1.2,1,2,3.2,4,2,3,4,5,6,7]
z=filter(int,list)
z=filter(lambda x:isinstance(x, int),list)
print ("filter: ",z)