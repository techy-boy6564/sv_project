list=[12,23,34,45,56,67,78,89]
print('org list is: ',list)

list.append(21)
print ('append 12',list)

poped2=list.pop()
print ('poped ind',poped2)

poped=list.pop (2)
print ('pop 2 ind',poped)

re=list.remove(12)
print ('remove 12 ',re)

list2=[1,2,3,4,5]
list3=list+list2
print ('combidend list',list3)

list.extend(list2)
print ('added list',list)

x_list=range(1,8)
print (x_list)

x_list.insert(4, 9)
print (x_list)

x_list.reverse()
print (x_list)