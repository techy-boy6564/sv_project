import logging

logging_file='teslog.log'

logging.basicConfig(
    format='%(asctime)s : %(levelname)s : %(message)s',
    filename=logging_file,
    filemode='w'
)

logging.debug("start of the program")
logging.info('doing something')
logging.warning('dying now')
logging.error('shutdown the system')
logging.fatal('It\'s a FATAL ERROR')
logging.critical('It\'s very critical')
