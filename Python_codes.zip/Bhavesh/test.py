from sketchpy import library as lib

obj = lib.rdj()

obj.draw()